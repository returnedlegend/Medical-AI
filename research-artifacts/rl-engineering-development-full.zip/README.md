# Early synthetic RL engineering outputs

All recognized saved early RL result JSON files are preserved, including handoff-only, zero-success and harmful variants. Read MANIFEST.json for per-run outcomes, original paths and exact byte hashes. These inspected runs are development data, and historical source capture is incomplete. Older model versions are not current playable references. No weights, reward or physiology are changed by this archive. The frozen multi-seed studies and independent final test have separate artifacts.
