"""Independent saved-data verification; no simulator or policy modules imported."""
import csv
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path

import numpy as np

ROOT = Path('/workspace/Medical-AI')
DATA = ROOT / '.data/final-fixed-policy-evaluation-001'
REPORT = ROOT / '.data/final-fixed-policy-evaluation-001-report'

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()

def read(path):
    def reject(value):
        raise ValueError('Nonfinite JSON: ' + value)
    raw = path.read_bytes()
    return json.loads(raw, parse_constant=reject), raw

def equal(a, b):
    assert math.isfinite(float(a)) and math.isclose(float(a), float(b), rel_tol=1e-10, abs_tol=1e-10), (a, b)

def interval(k, n):
    z = 1.959963984540054
    center = (k + .5*z*z)/(n+z*z)
    half = z*math.sqrt(k*(1-k/n)+z*z/4)/(n+z*z)
    return [max(0., center-half), min(1., center+half)]

def main():
    marker, marker_raw = read(DATA/'complete.marker')
    protocol, protocol_raw = read(DATA/'protocol.json')
    results, results_raw = read(DATA/'results.json')
    freeze_path = ROOT/'examples/final-evaluation-001-policy-freeze.json'
    design_path = ROOT/'examples/final-evaluation-001-design.json'
    plan_path = ROOT/'examples/final-evaluation-001-crossed-analysis.json'
    freeze, freeze_raw = read(freeze_path)
    design, design_raw = read(design_path)
    plan, plan_raw = read(plan_path)
    assert not (DATA/'failed.json').exists()
    assert marker['protocol_sha256']==digest(protocol_raw)==results['protocol_sha256']
    assert marker['results_sha256']==digest(results_raw)
    assert protocol['phase']==results['phase']=='final'
    assert results['policy_selection_performed'] is False
    assert freeze['design_file_sha256']==digest(design_raw)==plan['design_sha256']
    assert protocol['physics_fingerprint']==freeze['physics_fingerprint']==design['physics_fingerprint']
    assert protocol['source_sha256']==freeze['source_sha256']
    assert protocol['environment_config']==freeze['environment_config']
    patients=protocol['patient_seeds'];n=len(patients)
    assert patients==design['patient_seeds']==plan['shared_patient_seeds']==list(range(20000,20128))
    assert digest(canonical(patients))==protocol['patient_seed_sha256']==freeze['patient_seed_sha256']
    excluded, excluded_raw=read(ROOT/freeze['prior_seed_exclusions']['source'])
    assert len(excluded)==60565 and excluded==sorted(set(excluded))==protocol['prior_used_patient_seeds']
    assert digest(canonical(excluded))==protocol['prior_used_seed_set_sha256']==freeze['prior_seed_exclusions']['canonical_sha256']
    assert digest(excluded_raw)==freeze['prior_seed_exclusions']['raw_file_sha256']
    assert not set(patients)&set(excluded)
    expected_labels=['policy:'+row['label'] for row in design['policies']]+['baseline:'+name for name in design['baselines']]
    controllers=results['controllers'];assert list(controllers)==expected_labels
    assert len(controllers)==15 and len(freeze['policies'])==12
    for record in freeze['policies']:
        payload,raw=read(DATA/'inputs'/('policy-'+record['label']+'.json'))
        run=payload.get('result',payload)
        assert digest(raw)==record['file_sha256'] and digest(canonical(run))==record['result_sha256']
        assert digest(canonical(run['checkpoint']))==record['checkpoint_sha256']
        assert run['config']==record['training_config']
        assert set(run['metadata']['training_seeds']+run['metadata']['test_seeds'])<=set(excluded)
    metrics={};identities=set();anatomy=None;flat=[]
    config=protocol['environment_config']
    for label,value in controllers.items():
        rows=value['episodes'];assert len(rows)==value['n']==n
        assert [row['seed'] for row in rows]==patients
        current=[canonical(row['patient']) for row in rows]
        assert len(set(current))==n
        if anatomy is None:anatomy=current
        else:assert current==anatomy
        for row in rows:
            key=(label,row['seed']);assert key not in identities;identities.add(key)
            assert all(type(row[k]) is bool for k in ('success','severe_harm','handoff','terminated','truncated'))
            assert row['success']==(row['outcome']=='success')
            assert row['handoff']==(row['outcome']=='handoff')
            assert row['truncated']==(row['outcome']=='time_limit') and row['terminated']!=row['truncated']
            assert 1<=row['steps']<=config['max_steps']
            assert 0<=row['critical_damage']<=row['max_damage']<=1
            assert row['blood_loss_ml']>=0 and row['bile_leak_ml']>=0
            severe=(row['max_damage']>=config['injury_termination_threshold'] or row['critical_damage']>=config['critical_injury_threshold'] or row['blood_loss_ml']>=config['blood_loss_termination_ml'])
            assert row['severe_harm']==severe
            if row['success']:assert row['max_damage']<.15 and row['critical_damage']<.08 and row['final_exposure']>=config['exposure_target']
            equal(row['return'],math.fsum(row['reward_components_total'].values()))
            equal(row['reward_components_total']['step'],-.01*row['steps'])
            flat.append({'controller':label,**row})
        metric={'n':n,'successes':sum(row['success'] for row in rows),'severe_harm_episodes':sum(row['severe_harm'] for row in rows),'handoffs':sum(row['handoff'] for row in rows)}
        for key in ('successes','severe_harm_episodes','handoffs'):assert metric[key]==value[key]
        for rate,count in [('success_rate','successes'),('severe_harm_rate','severe_harm_episodes')]:
            metric[rate]=metric[count]/n;equal(metric[rate],value[rate]);metric[rate+'_wilson_ci']=interval(metric[count],n)
            for a,b in zip(metric[rate+'_wilson_ci'],value[rate+'_wilson_ci']):equal(a,b)
        for name,field in [('mean_return','return'),('mean_max_damage','max_damage'),('mean_blood_loss_ml','blood_loss_ml')]:
            metric[name]=math.fsum(row[field] for row in rows)/n;equal(metric[name],value[name])
        metrics[label]=metric
    assert len(identities)==len(flat)==marker['completed_episodes']==results['observed_episodes']==results['expected_episodes']==design['expected_episodes']==1920
    log_raw=(DATA/'episodes.jsonl').read_bytes();logged=[json.loads(line) for line in log_raw.splitlines()];assert logged==flat
    # Independent frequency-weight implementation of the common patient bootstrap.
    reps=2000;rng=np.random.default_rng(99174)
    weights=np.array([np.bincount(rng.integers(0,n,n),minlength=n)/n for _ in range(reps)])
    returns=np.array([[row['return'] for row in controllers[label]['episodes']] for label in expected_labels])
    sample_means=weights@returns.T
    by_label={label:i for i,label in enumerate(expected_labels)}
    assert len(results['contrasts'])==105
    pairs=set()
    for contrast in results['contrasts']:
        pos,neg=contrast['positive_controller'],contrast['negative_controller'];pair=frozenset((pos,neg));assert pair not in pairs;pairs.add(pair)
        p,q=by_label[pos],by_label[neg];equal(contrast['mean_return_difference'],np.mean(returns[p]-returns[q]))
        for a,b in zip(contrast['paired_patient_bootstrap_ci'],np.quantile(sample_means[:,p]-sample_means[:,q],[.025,.975])):equal(a,b)
    # Independent crossed bootstrap using row/column multinomial frequencies.
    matrices={metric:np.array([[float(a[metric])-float(b[metric]) for a,b in zip(controllers[f"policy:{plan['positive_arm']}_seed{seed}"]['episodes'],controllers[f"policy:{plan['negative_arm']}_seed{seed}"]['episodes'])] for seed in plan['paired_training_seeds']]) for metric in plan['metrics']}
    assert plan['paired_training_seeds']==list(range(201,206)) and plan['bootstrap_seed']==99175 and plan['bootstrap_replicates']==2000
    rng=np.random.default_rng(99175);crossed_samples={key:[] for key in matrices}
    for _ in range(2000):
        rw=np.bincount(rng.integers(0,5,5),minlength=5)/5
        cw=np.bincount(rng.integers(0,n,n),minlength=n)/n
        for key,matrix in matrices.items():crossed_samples[key].append(float(np.sum(rw[:,None]*cw[None,:]*matrix)))
    crossed=[{'metric':key,'mean_difference':float(matrix.mean()),'crossed_ci_lower':float(np.quantile(crossed_samples[key],.025)),'crossed_ci_upper':float(np.quantile(crossed_samples[key],.975))} for key,matrix in matrices.items()]
    report_manifest,report_raw=read(REPORT/'report-complete.json')
    assert report_manifest['simulator_executed'] is False and report_manifest['policy_selection_performed'] is False
    assert report_manifest['input_sha256']['protocol.json']==digest(protocol_raw) and report_manifest['input_sha256']['results.json']==digest(results_raw)
    for name,expected in report_manifest['outputs_sha256'].items():assert digest((REPORT/name).read_bytes())==expected
    with (REPORT/'controllers.csv').open() as f:
        for row in csv.DictReader(f):
            label=row['controller'];m=metrics[label]
            for key in ('n','successes','severe_harm_episodes','handoffs','mean_return','mean_max_damage','mean_blood_loss_ml'):equal(row[key],m[key])
            expected=np.quantile(sample_means[:,by_label[label]],[.025,.975])
            equal(row['mean_return_ci_lower'],expected[0]);equal(row['mean_return_ci_upper'],expected[1])
    with (REPORT/'study003-crossed-contrasts.csv').open() as f:
        recorded={row['metric']:row for row in csv.DictReader(f)}
    for row in crossed:
        for key in ('mean_difference','crossed_ci_lower','crossed_ci_upper'):equal(recorded[row['metric']][key],row[key])
    audit={'format':'retraction-independent-final-audit-v1','complete':True,'audited_at':datetime.now(timezone.utc).isoformat(),'simulator_executed':False,'policy_selection_performed':False,
           'input_sha256':{'complete.marker':digest(marker_raw),'protocol.json':digest(protocol_raw),'results.json':digest(results_raw),'episodes.jsonl':digest(log_raw),'design':digest(design_raw),'policy_freeze':digest(freeze_raw),'crossed_plan':digest(plan_raw),'prior_exclusions':digest(excluded_raw)},
           'audit_source_sha256':digest(Path(__file__).read_bytes()),'recorded_rollouts':1920,'fixed_policies':12,'common_baselines':3,'shared_patients':128,'excluded_prior_seeds':60565,
           'checks':{key:'PASS' for key in ('completion_hashes','frozen_policy_and_decoder_hashes','prior_seed_exclusion','all1920unique_controller_patient_rows','paired_anatomy','outcome_and_reward_consistency','raw_aggregate_and_wilson_reconstruction','append_only_log_identity','all105paired_return_bootstrap_intervals','independent_crossed_frequency_bootstrap','report_output_hashes_and_values')},
           'controller_metrics':metrics,'paired_return_contrasts_verified':105,'crossed_contrasts':crossed,
           'report_sha256':{'report-complete.json':digest(report_raw),**{name:digest((REPORT/name).read_bytes()) for name in ('controllers.csv','paired-return-contrasts.csv','study003-crossed-contrasts.csv')}},
           'method':'Read-only stdlib/NumPy verification without evaluator/reporter/model imports. Bootstrap intervals independently reconstructed with multinomial frequency weights; crossed patient weights shared across paired training seeds and outcomes.',
           'limitations':['128 shared synthetic patients, not1920 independent patients.','Five training seeds give unstable descriptive crossed intervals; multiple comparisons unadjusted.','No clinical/model validation or policy promotion follows from this audit.']}
    path=ROOT/'.data/final-evaluation-001-independent-audit.json'
    with path.open('x') as f:json.dump(audit,f,indent=2,allow_nan=False);f.write('\n')
    print(json.dumps({'complete':True,'audit':str(path),'sha256':digest(path.read_bytes()),'crossed_contrasts':crossed}))

if __name__=='__main__':main()
